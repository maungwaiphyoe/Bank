import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class TransferView extends StatefulWidget {
  @override
  _TransferViewState createState() {
    // TODO: implement createState
    return _TransferViewState();
  }
}

class _TransferViewState extends State<TransferView> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("Transfer"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width / 1.5,
              child: TextField(
                  decoration:
                      InputDecoration(hintText: "Enter Amount to Transfer")),
            ),
            Container(
              width: MediaQuery.of(context).size.width / 1.5,
              child: TextField(
                  decoration:
                      InputDecoration(hintText: "Enter Acc No. to Transfer")),
            ),
            SizedBox(
              height: 10,
            ),
            RaisedButton(
              child: Text(
                "     Transfer     ",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  // fontStyle: FontStyle.italic,
                  fontSize: 18,
                ),
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18.0),
              ),
              color: Colors.indigoAccent,
              onPressed: () {},
            )
          ],
        ),
      ),
    );
  }
}
