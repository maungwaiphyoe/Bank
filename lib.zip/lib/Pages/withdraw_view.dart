import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class WithdrawView extends StatefulWidget {
  @override
  _WithdrawViewState createState() {
    // TODO: implement createState
    return _WithdrawViewState();
  }
}

class _WithdrawViewState extends State<WithdrawView> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Withdraw",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            // fontStyle: FontStyle.italic,
            fontSize: 18,
          ),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width / 1.5,
              child: TextField(
                  decoration:
                      InputDecoration(hintText: "Enter Amount to Withdraw")),
            ),
            // Container(
            //   width: MediaQuery.of(context).size.width / 1.5,
            //   child: TextField(),
            // ),
            SizedBox(
              height: 10,
            ),

            RaisedButton(
              child: Text("Withdraw"),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18.0),
              ),
              color: Colors.indigoAccent,
              onPressed: () {},
            )
          ],
        ),
      ),
    );
  }
}
