import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SavingView extends StatefulWidget {
  @override
  _SavingViewState createState() {
    // TODO: implement createState
    return _SavingViewState();
  }
}

class _SavingViewState extends State<SavingView> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("Saving"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width / 1.5,
              child: TextField(decoration: InputDecoration(hintText: "Enter Amount to Save")),
            ),
            // Container(
            //   width: MediaQuery.of(context).size.width / 1.5,
            //   child: TextField(),
            // ),
            SizedBox(
              height: 10,
            ),

            RaisedButton(
              child: Text("     Save     ",
               style: TextStyle(
                    fontWeight: FontWeight.bold,
                    // fontStyle: FontStyle.italic,
                    fontSize: 18,
                    ),),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18.0),
              ),
              color: Colors.indigoAccent,
              onPressed: () {},

            )
          ],
        ),
      ),
    );
  }
}
