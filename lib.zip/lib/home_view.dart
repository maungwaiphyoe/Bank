import 'package:databasemasterdemo/Pages/Transfer_view.dart';
import 'package:databasemasterdemo/Pages/history_view.dart';
import 'package:databasemasterdemo/Pages/saving_view.dart';
import 'package:databasemasterdemo/Pages/withdraw_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomeView extends StatefulWidget {
  @override
  _HomeViewState createState() {
    // TODO: implement createState
    return _HomeViewState();
  }
}

class _HomeViewState extends State<HomeView> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("Home"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "Total Amount:78990000 MMK",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                RaisedButton(
                  color: Colors.lightGreen,
                  child: Container(
                    height: 100,
                    width: 100,
                    child: Center(
                      child: Text(
                        "Saving",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        new MaterialPageRoute(
                            builder: (context) => SavingView()));
                  },
                ),
                SizedBox(
                  width: 5,
                ),
                RaisedButton(
                  color: Colors.redAccent,
                  child: Container(
                    height: 100,
                    width: 100,
                    child: Center(
                      child: Text(
                        "Withdraw",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        new MaterialPageRoute(
                            builder: (context) => WithdrawView()));
                  },
                ),
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                RaisedButton(
                  color: Colors.yellowAccent,
                  child: Container(
                    height: 100,
                    width: 100,
                    child: Center(
                      child: Text(
                        "Transfer",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        new MaterialPageRoute(
                            builder: (context) => TransferView()));
                  },
                ),
                SizedBox(
                  width: 5,
                ),
                RaisedButton(
                  color: Colors.blueAccent,
                  child: Container(
                    height: 100,
                    width: 100,
                    child: Center(
                      child: Text(
                        "History",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20),
                      ),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        new MaterialPageRoute(
                            builder: (context) => HistoryView()));
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
